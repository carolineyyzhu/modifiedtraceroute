# Modified Traceroute Tool
Caroline Zhu, CSDS 325 Computer Networks I, Fall 2020\
Lightweight traceroute tool that measures the number of hops and the RTT of a packet sent to specific websites in the configuration file of the project, targets.txt

To run the program, use 'python3 distMeasurement.py'

#### On the VM, file locations are as follows:
- **Location of source code:** /home/eecs-user/project2grading/
